const SignUpPage = () => {
  return (
    <div>SignUpPage</div>
  );
};

export default SignUpPage