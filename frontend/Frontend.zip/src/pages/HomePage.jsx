const HomePage = () => {
  return (
    <div className='hero-bg h-screen'>HomePage</div>
  )
}

export default HomePage